"""Render mocked draw-call captures; font is an approximate 3x5 bitmap."""
import json
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
GLYPHS = {
    '0':'111/101/101/101/111', '1':'010/110/010/010/111',
    '2':'110/001/010/100/111', '3':'110/001/010/001/110',
    '4':'101/101/111/001/001', '5':'111/100/110/001/110',
    '6':'011/100/111/101/111', '7':'111/001/010/010/010',
    '8':'111/101/111/101/111', '9':'111/101/111/001/110',
    '.':'000/000/000/000/010', '+':'000/010/111/010/000',
    '-':'000/000/111/000/000', '%':'101/001/010/100/101',
    'W':'101/101/101/111/101', 'k':'100/101/110/101/101',
    'h':'100/100/110/101/101', 'I':'111/010/010/010/111',
    'M':'101/111/111/101/101', 'P':'110/101/110/100/100',
    'O':'111/101/101/101/111', 'R':'110/101/110/101/101',
    'T':'111/010/010/010/010', 'E':'111/100/110/100/111',
    'X':'101/101/010/101/101', 'L':'100/100/100/100/111',
    'A':'010/101/111/101/101', 'D':'110/101/101/101/110',
}

def render_calls(commands):
    im = Image.new('RGB', (52, 16))
    draw = ImageDraw.Draw(im)
    for kind, *args in commands:
        color = args[-1]
        color = ((color >> 16) & 255, (color >> 8) & 255, color & 255)
        if kind == 'text':
            x, baseline, label, _ = args
            for char in label:
                for y, row in enumerate(GLYPHS[char].split('/')):
                    for dx, bit in enumerate(row):
                        if bit == '1':
                            draw.point((x + dx, baseline - 5 + y), fill=color)
                x += 4
        elif kind == 'pixel':
            draw.point(tuple(args[:2]), fill=color)
        elif kind == 'line':
            draw.line(tuple(args[:4]), fill=color)
        else:
            x, y, w, h, _ = args
            bounds = (x, y, x+w-1, y+h-1)
            draw.rectangle(bounds, **({'fill':color} if kind == 'fill' else {'outline':color}))
    return im.resize((520, 160), Image.Resampling.NEAREST)

def render(name):
    return render_calls(json.loads((ROOT / f'preview-{name}.json').read_text()))

names = ['solar', 'battery', 'house', 'import', 'export', 'solar-half', 'house-unknown']
sheet = Image.new('RGB', (1100, 835), '#15181c')
draw = ImageDraw.Draw(sheet)
draw.text((20, 10), 'SolarApp TC002 - simulated layout, approximate font', fill='white')
for i, name in enumerate(names):
    x = 20 + (i % 2)*550
    y = 45 + (i // 2)*195
    draw.text((x, y), name, fill='#bac4ce')
    sheet.paste(render(name), (x, y+20))
sheet.save(ROOT / 'preview.png')
capture = ROOT / 'animation-frames.json'
frames = ([render_calls(frame) for frame in json.loads(capture.read_text())]
          if capture.exists() else [render(name) for name in names[:5]])
frames[0].save(ROOT / 'rotation-preview.gif', save_all=True, append_images=frames[1:],
               duration=100 if capture.exists() else 2200, loop=0)
if capture.exists() and len(frames) >= 120:
    fallback = frames[100:120]
    fallback[0].save(ROOT / 'house-load-preview.gif', save_all=True,
                     append_images=fallback[1:], duration=100, loop=0)
print('Created simulated preview.png and rotation-preview.gif')
