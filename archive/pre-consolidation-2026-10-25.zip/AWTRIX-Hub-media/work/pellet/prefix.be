# Run from docs/awtrixng with a Berry 1.1 interpreter. No network/device calls.
import json
import string
var cfg = {}
var clock_ms = 0
var subscriptions = {}
var messages = []
var drawing = []
var checks = 0
var advances = {" ":2, "!":2, "'":2, "(":3, ")":3, ",":3, ".":2, ":":2, ";":3,
  "I":2, "M":6, "N":5, "Q":5, "W":6, "`":3, "i":2, "|":2}
var store = module("store")
store.get = def (key, fallback) return cfg.find(key, fallback) end
var mqtt = module("mqtt")
mqtt.subscribe = def (topic, callback) subscriptions[topic] = callback end
def now_ms() return clock_ms end
def log(message) messages.push(message) end
def num(value, fallback)
  if type(value) == "string"
    try value = json.load(value) except .. return fallback end
  end
  return type(value) == "int" || type(value) == "real" ? value : fallback
end
def format(pattern, value) return string.format(pattern, value) end
def max(a, b) return a > b ? a : b end
def min(a, b) return a < b ? a : b end
def clamp(v, a, b) return max(a, min(v, b)) end
def font(name) assert(name == "small") end
# Native small-font ASCII advances, checked against the vendored BDF by verify.py.
def text_width(label)
  var width = 0
  for index : 0 .. size(label) - 1
    var ch = label[index .. index]
    width += advances.find(ch, 4)
  end
  return width
end
def clear() drawing = [] end
def point_ok(x, y) assert(x >= 0 && x < 52 && y >= 0 && y < 16, "point out of bounds") end
def pixel(x, y, color)
  point_ok(x, y)
  drawing.push(["pixel", x, y, color])
end
def line(x, y, x2, y2, color)
  point_ok(x, y) point_ok(x2, y2)
  drawing.push(["line", x, y, x2, y2, color])
end
def rect_fill(x, y, w, h, color)
  assert(w > 0 && h > 0, "invalid rectangle")
  point_ok(x, y) point_ok(x + w - 1, y + h - 1)
  drawing.push(["fill", x, y, w, h, color])
end
def text(x, y, label, color)
  assert(x == 17 && text_width(label) <= 34, "text exceeds allocated area: " + label)
  assert(y == 6 || y == 14, "unexpected baseline")
  drawing.push(["text", x, y, label, color])
end
def check(condition, message)
  assert(condition, message)
  checks += 1
end
def has_label(label)
  for call : drawing
    if call[0] == "text" && call[3] == label return true end
  end
  return false
end
def has_art()
  for call : drawing
    if call[0] != "text" && call[1] < 16 return true end
  end
  return false
end
def new_app(settings)
  cfg = settings
  clock_ms = 0
  subscriptions = {}
  messages = []
  var app = compile("PelletStove.ax", "file")()
  app.setup()
  return app
end
def feed(app, index, payload) app.receive(app.topics[index], payload) end
def state(app)
  app.receive(app.topics[9], '{"onoff":true,"stove_mode":"heating","stove_status":true,"measure_temperature":21.4,"target_temperature":22,"stove_pellets_actual":8.4,"measure_stove_cleaning_in":32.5,"measure_stove_maintenance_in":45,"stove_error_state":false}')
end
def full_app(settings)
  settings["topic_state"] = "test/state"
  var app = new_app(settings)
  state(app)
  app.on_show()
  return app
end
def capture(path, value)
  var f = open(path, "w")
  f.write(json.dump(value))
  f.close()
end

